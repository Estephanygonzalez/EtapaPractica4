package JavaBasics;

public class OperacionesBasicasVariables {
    public static void main(String[] args) {
        int a = 5, b = 3, c;
         c= a+b;
        System.out.println("La suma es :"+ c);
         c = a-b;
        System.out.println("La resta es :"+ c);
        c= a*b;
        System.out.println("La multiplicacion es:"+ c);
        double d= a/b;
        System.out.println("La division es:"+ d);
    }
}

