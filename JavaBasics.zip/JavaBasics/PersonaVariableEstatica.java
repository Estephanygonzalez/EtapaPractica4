package JavaBasics;
/*
Las variables y métodos estáticos en Java sirven para que puedan ser accedidos desde cualquier parte
del código (inclusive desde otras clases) sin tener que crear un objeto
 */
public class PersonaVariableEstatica {
    //Crear 2 Variables Static//
    public static String nombre;
    public static int edad;

   //Acceder y establecer nuevos valores a las variables//
    public static void main(String[] args) {
        PersonaVariableEstatica.nombre = "Juan";
        PersonaVariableEstatica.edad = 12;

        System.out.println("nombre = " + PersonaVariableEstatica.nombre+ ";Edad:"+PersonaVariableEstatica.edad);
    }
}
