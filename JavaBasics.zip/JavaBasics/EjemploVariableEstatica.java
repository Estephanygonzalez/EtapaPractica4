package JavaBasics;

/*
Las variables y métodos estáticos en Java sirven para que puedan ser accedidos desde cualquier parte
del código (inclusive desde otras clases) sin tener que crear un objeto
 */
public class EjemploVariableEstatica {
     static int contador ;//static es propia de la clase//

    public EjemploVariableEstatica(){
        contador++;
        System.out.println("contador = " + contador);

    }

    public static void main(String[] args) {
        EjemploVariableEstatica e1=new EjemploVariableEstatica();
        EjemploVariableEstatica e2=new EjemploVariableEstatica();
        EjemploVariableEstatica e3=new EjemploVariableEstatica();
        EjemploVariableEstatica e4=new EjemploVariableEstatica();

        /*Cada vez que se llama el objeto el metodo
         constructor ejecuta la funcion contador,Cuando no es
         Static es Contador1,contador1,contador1,contador1/
        /*
        Cuando es Static el constructor va sumando e incrementando
        los resultados de cada una de las variables:
        contador1,contador2,contador3,contador4
         */


    }
}
