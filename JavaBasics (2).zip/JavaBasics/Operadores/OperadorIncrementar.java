package JavaBasics.Operadores;

import java.util.Scanner;

public class OperadorIncrementar {
    public static void main(String[] args) {
        var edad = Integer.parseInt("20");
        System.out.println("edad = " + edad);
        System.out.println("edad = " + (edad + 1));

        var edad1 = "20";
        System.out.println("edad1 = " + edad1);
        System.out.println(" edad1 + 1 = " + (edad1 + 1));

        var valorPi = Double.parseDouble("3.1416");
        System.out.println("valorPi = " + valorPi);

        //Pedir un valos Scanner
        var consola = new Scanner(System.in);
        System.out.println("Digite su edad :");
        edad = Integer.parseInt(consola.nextLine());
        System.out.println("edad = " + edad);

        var edadTexto = String.valueOf(10);
        System.out.println("edadTexto = " + edadTexto);

        //Operadores

        int a = 3, b = 2;
        int c = a + 4 - b;
        System.out.println("c = " + c);
        //Incrementar
        a += 1;

        System.out.println("a = " + a);

        a -= 1;
        //Reducir
        System.out.println("a = " + a);

        int d = 3;
        int e = -d;
        System.out.println("d = " + d);
        System.out.println("e = " + e);

        var f = true;
        var g = !f;
        System.out.println("f = " + f);
        System.out.println("g = " + g);

        //preincremento variables
        var h = 5;
        var i = h++;
        System.out.println("h = " + h);
        System.out.println("i = " + i);

        //Decremento
        var j = 7;
        var k = --j;
        System.out.println("j = " + j);
        System.out.println("k = " + k);
    }
    }