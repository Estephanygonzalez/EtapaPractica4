package JavaBasics.Operadores;

import java.util.Scanner;

public class OperadorTernario {
    public static void main(String[] args) {
        //variable = condicion ? si es verdadero : si es falso;
        String variable = 7 == 7 ? "si es verdadero" : "si es falso";
        System.out.println("variable = " + variable);

        //Ejemplo 2//
        int max = 0;

        Scanner s = new Scanner(System.in);
        System.out.println("Ingrese Un  numero");
        int num1 = s.nextInt();

        System.out.println("Ingrese el segundo numero");
        int num2 = s.nextInt();

        System.out.println("Ingrese el tercer numero");
        int num3 = s.nextInt();

        max = (num1 > num2) ? num1 : num2;
        max = (max > num3) ? max : num3;

        System.out.println("num1 = " + num1);
        System.out.println("num2 = " + num2);
        System.out.println("num3 = " + num3);
        System.out.println("El numero Mayor es maximo = " + max);


    }
}