package JavaBasics.TiposDatos;

public class EjemploString {
    public static void main(String[] args) {
        String curso = "Programacion Java";//instancia en la literal STRING
        String curso2 = new String("Programacion Java");//Crea una instancia de la clase string
        boolean esIgual = curso == curso2;//Compara las instancia (Objetos)
        System.out.println("esIgual = " + esIgual);

        esIgual = curso.equals(curso2);//compara que los valores sean iguales
        System.out.println("esIgual = " + esIgual);//Contenido del objeto(Valor)

        esIgual = curso.equalsIgnoreCase(curso2);//compara los valores sin necesidad de mirar mayusculas
        System.out.println("esIgual = " + esIgual);

        String curso3 = "Programacion Java";
        esIgual = curso == curso3;
        System.out.println("esIgual =" + esIgual);
    }
}
